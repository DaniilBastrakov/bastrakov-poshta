﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Выдача_зарплаты : Form
    {
        public Выдача_зарплаты()
        {
            InitializeComponent();
        }

        private void Выдача_зарплаты_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            using (var db = new Почтовое_отделениеEntities1())
            {
                var otchet = new Бухгалтерия();
                otchet.ID_сотрудника = int.Parse(textBox1.Text);
                otchet.ID_отчёта = int.Parse(textBox2.Text);
                otchet.Зарплата = decimal.Parse(textBox3.Text);
                var a = int.Parse(textBox1.Text);
                var resultsearch = db.Бухгалтерия.FirstOrDefault(item => item.ID_сотрудника == a);
                if (resultsearch == null)
                {
                    db.Бухгалтерия.Add(otchet);
                    db.SaveChanges();
                    MessageBox.Show("Вы, успешно добавили Запись Бухгалтера");
                }
                else
                {
                    MessageBox.Show("Такая запись уже существует,введите другую");
                }
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            using (var db = new Почтовое_отделениеEntities1())
            {
                var otchet = new Бухгалтерия();
                otchet.ID_сотрудника = int.Parse(textBox1.Text);
                otchet.ID_отчёта = int.Parse(textBox2.Text);
                otchet.Зарплата = decimal.Parse(textBox3.Text);
                var a = int.Parse(textBox1.Text);
                var resultsearch = db.Бухгалтерия.FirstOrDefault(item => item.ID_сотрудника == a);
                if (resultsearch == null)
                {
                    db.Бухгалтерия.Remove(otchet);
                    db.SaveChanges();
                    MessageBox.Show("Вы, успешно удалили запись Бухгалтера");
                }
                else
                {
                    MessageBox.Show("Такая запись уже существует,введите другую");
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Бухгалтер ф = new Бухгалтер();
            ф.Show();
            Hide();
        }
    }
}
