﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        int countCheckLogin = 0;
        int maxCountCheckLogin = 3;
        int timerQ = 60;
        string str = " ";

        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            using (var db = new Почтовое_отделениеEntities1())
            {
                var resultsearch = db.Пользователь.FirstOrDefault(item => item.Логин == textBox3.Text && item.Пароль == textBox4.Text);

                if (resultsearch != null)

                {
                    var sot = db.Сотрудник.FirstOrDefault(a => a.Логин == textBox3.Text);
                    if (sot == null)
                    { MessageBox.Show("Такого пользователя нельзя зарегестрировать,так как не выданы права,измените данные в таблице"); }
                    else
                    {
                        if (sot.Должность == "Кассир")
                        {
                            Касса кассир = new Касса();
                            кассир.Show();
                            Hide();
                        }
                        if (sot.Должность == "Бухгалтер")
                        {
                            Бухгалтер кассир = new Бухгалтер();
                            кассир.Show();
                            Hide();
                        }
                        if (sot.Должность == "Директор")
                        {
                            Директор кассир = new Директор();
                            кассир.Show();
                            Hide();
                        }
                        //MessageBox.Show("Успешный вход," + " " + resultsearch.Логин);

                    }
                }
                else
                {
                    countCheckLogin++;
                    if (maxCountCheckLogin - countCheckLogin == 0)
                    {
                        button2.Enabled = false;
                        button1.Enabled = false;
                        textBox3.Enabled = false;
                        textBox4.Enabled = false;
                        MessageBox.Show($"Вы потратили свои попытки.Повторить можно через 1 минуту.");
                        label1.Visible = true;
                        timer1.Enabled = true;
                    }

                    var user = db.Сотрудник.FirstOrDefault(user1 => user1.Логин == textBox3.Text);
                    MessageBox.Show("Неудачный вход.Проверьте правильность написания данных или пройдите регистрацию");

                }

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            using (var db = new Почтовое_отделениеEntities1())
            {
                var Авторизация1 = new Пользователь();
                Авторизация1.Логин = textBox3.Text;
                Авторизация1.Пароль = textBox4.Text;
                var resultsearch = db.Пользователь.FirstOrDefault(item => item.Логин == textBox3.Text);
                if (resultsearch == null)
                {
                    db.Пользователь.Add(Авторизация1);
                    db.SaveChanges();
                    MessageBox.Show("Вы, успешно прошли регистрацию");
                }
                else
                {
                    MessageBox.Show("Такой логин или пароль уже существует,введите другой");
                }
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timerQ--;
            label1.Text = timerQ.ToString();

            if (timerQ <= 0)
            {
                timer1.Enabled = false;
                label1.Visible = false;
                button2.Enabled = true;
                textBox3.Enabled = true;
                textBox4.Enabled = true;
                button1.Enabled = true;
                countCheckLogin = 0;
                timerQ = 60;
                timer1.Stop();
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            WriteDocument();

            string[] str1 = str.Split('/');
            timerQ = int.Parse(str1[1]);
            countCheckLogin = int.Parse(str1[2]);

            if(countCheckLogin == maxCountCheckLogin)
            {
                label1.Visible = true;
                timer1.Enabled = true;
                label1.Enabled = true;
                button2.Enabled = false;
                button1.Enabled = false;
                textBox3.Enabled = false;
                textBox4.Enabled = false;
                label1.Text = timerQ.ToString();
            }
        }
        private void SaveDataInDocument()
        {
            string filePath = "D://Практика Бастраков Даниил/1.txt";
            string text = $"{DateTime.Now.ToString()}/{timerQ.ToString()}/{countCheckLogin.ToString()}";
            FileStream fileStream = File.Open(filePath, FileMode.Create);
            StreamWriter output = new StreamWriter(fileStream);
            output.Write(text);
            output.Close();
        }
        private void WriteDocument()
        {
            string filePath = "D://Практика Бастраков Даниил/1.txt";
            try
            {
                using (StreamReader sr = new StreamReader(filePath))
                {
                    str = sr.ReadToEnd();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            
        }
        private void FormLogin_FormClosed(object sender, FormClosedEventArgs e)
        {
            SaveDataInDocument();
        }
        
    }
}

