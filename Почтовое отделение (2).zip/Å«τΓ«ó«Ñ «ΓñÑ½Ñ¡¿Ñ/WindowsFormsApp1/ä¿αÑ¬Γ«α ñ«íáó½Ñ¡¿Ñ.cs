﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Директор_добавление : Form
    {
        public Директор_добавление()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Директор кассир = new Директор();
            кассир.Show();
            Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Сотрудник сотрудник = new Сотрудник
            {
                ID_сотрудника = int.Parse(textBox1.Text),
                Фамилия = textBox2.Text,
                Имя = textBox3.Text,
                Отчество = textBox4.Text,
                Телефон = textBox5.Text,
                Адрес = textBox6.Text,
                Должность = textBox7.Text,
                Логин = textBox8.Text
            };

            using (var db = new Почтовое_отделениеEntities1())
            {
                var a = int.Parse(textBox1.Text);
                var resultsearch = db.Сотрудник.FirstOrDefault(item => item.ID_сотрудника == a);
                if (resultsearch == null)
                {
                    db.Сотрудник.Add(сотрудник);
                    db.SaveChanges();
                    MessageBox.Show("Вы, успешно приняли сотрудника в почтовое отделение");
                }
                else
                {
                    MessageBox.Show("Такой сотрудник уже существует,введите другого");
                }
            }
        }

        private void Директор_добавление_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            using (var db = new Почтовое_отделениеEntities1())
            {
                var a = int.Parse(textBox1.Text);
                var resultsearch = db.Сотрудник.FirstOrDefault(item => item.ID_сотрудника == a);
                var должность = db.Должность.FirstOrDefault(item => item.ID_сотрудника == a);
                if (resultsearch != null)
                {
                    db.Сотрудник.Remove(resultsearch);
                    db.Должность.Remove(должность);
                    db.SaveChanges();
                    MessageBox.Show("Вы, успешно уволили  сотрудника ");
                }
                else
                {
                    MessageBox.Show("Такой сотрудник уже уволен,введите другого");
                }
            }
               
        }
    }
}
