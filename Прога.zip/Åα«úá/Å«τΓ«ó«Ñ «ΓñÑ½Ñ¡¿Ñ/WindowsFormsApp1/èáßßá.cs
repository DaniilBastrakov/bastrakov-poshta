﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Касса : Form
    {
        public Касса()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Касса1 касса1 = new Касса1
            {
             ID_клиента = int.Parse(textBox1.Text),
            ID_кассира = int.Parse(textBox2.Text),
            ID_заказа = int.Parse(textBox3.Text)
        
            };

            using (var db = new Почтовое_отделениеEntities1()) {
                var a = int.Parse(textBox1.Text);
                var resultsearch = db.Касса1.FirstOrDefault(item => item.ID_клиента == a);
                if (resultsearch == null)
                {
                    db.Касса1.Add(касса1);
                    db.SaveChanges();
                    MessageBox.Show("Вы, успешно добавили клиента");
                }
                else
                {
                    MessageBox.Show("Такой клиент уже существует,введите другой");
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 кассир = new Form1();
            кассир.Show();
            Hide();
        }

      
    }
    
}
