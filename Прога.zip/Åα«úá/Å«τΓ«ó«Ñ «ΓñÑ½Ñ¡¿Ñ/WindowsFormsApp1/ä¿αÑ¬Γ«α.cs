﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Директор : Form
    {
        public Директор()
        {
            InitializeComponent();
        }

        private void Директор_Load(object sender, EventArgs e)
        {
            using (var db = new Почтовое_отделениеEntities1())
            {
                var a = db.Сотрудник.Select(b =>
                new
                {
                    b.ID_сотрудника,
                    b.Фамилия,
                    b.Имя,
                    b.Отчество,
                    b.Телефон,
                    b.Адрес,
                    b.Должность,
                    b.Логин
                }
                );
                dataGridView1.DataSource = a.ToList();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 кассир = new Form1();
            кассир.Show();
            Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Директор_добавление кассир = new Директор_добавление();
            кассир.Show();
            Hide();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
