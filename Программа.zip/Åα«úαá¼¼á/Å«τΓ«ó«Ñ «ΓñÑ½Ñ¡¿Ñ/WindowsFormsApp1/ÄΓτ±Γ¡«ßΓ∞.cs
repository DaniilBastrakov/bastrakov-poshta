﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Отчётность : Form
    {
        public Отчётность()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            using (var db = new Почтовое_отделениеEntities1())
            {
                var otchet = new Отчёт();
                otchet.ID_отчёта = int.Parse(textBox1.Text);
                otchet.Выполнен_отчёт = textBox2.Text;
                var a = int.Parse(textBox1.Text);
                var resultsearch = db.Отчёт.FirstOrDefault(item => item.ID_отчёта == a);
                if (resultsearch == null)
                {
                    db.Отчёт.Add(otchet);
                    db.SaveChanges();
                    MessageBox.Show("Вы, успешно добавили отчёт");
                }
                else
                {
                    MessageBox.Show("Такой отчёт уже существует,введите другой");
                }
            }
        }

        private void Отчётность_Load(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
using (var db = new Почтовое_отделениеEntities1())
            {
                var otchet = new Отчёт();
                otchet.ID_отчёта = int.Parse(textBox1.Text);
                otchet.Выполнен_отчёт = textBox2.Text;
                var a = int.Parse(textBox1.Text);
                var resultsearch = db.Отчёт.FirstOrDefault(item => item.ID_отчёта == a);
                if (resultsearch == null)
                {
                    db.Отчёт.Remove(otchet);
                    db.SaveChanges();
                    MessageBox.Show("Вы, успешно удалили отчёт");
                }
                else
                {
                    MessageBox.Show("Такой отчёт уже удалён,введите другой");
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Бухгалтер ф = new Бухгалтер();
            ф.Show();
            Hide();
        }
    }
}
